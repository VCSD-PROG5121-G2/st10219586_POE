/*
code attribution
adapted from https://stackoverflow.com/questions/637980/if-else-and-if-elseif
sharptooth
https://stackoverflow.com/users/57428/sharptooth
 */
package task.pkg1;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author DISD3
 */
public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Login loginMethod = new Login();
        Task2 taskClass = new Task2();
        String firstName;

        String lastName;

        System.out.println("\nPlease enter your First Name: ");

        firstName = input.next();

        System.out.println("\nPlease enter your Last Name: ");

        lastName = input.next();

        System.out.println("\nPlease enter username: ");

        String username = input.next();

        
        if (loginMethod.checkUserName(username) == true) {

            System.out.println("\nusername is correct");

            System.out.println("\nPlease enter password");

            String password = input.next();

            
            if (loginMethod.checkPasswordComplexity(password) == true) {

                System.out.println("\npassword is correct");

                System.out.println(loginMethod.registerUser(username, password));

                System.out.println("\nPlease enter your username to sign in: ");

                String userNamecheck = input.next();

                System.out.println("\nPlease enter your password to sign in: ");

                String passWordcheck = input.next();

                
                if (loginMethod.loginUser(username, password, userNamecheck, passWordcheck) == true) {

                    System.out.println(loginMethod.returnLoginStatus("success"));

                    System.out.println("\nWelcome " + firstName + " " + lastName + ", it is great to see you.");
                    
                    System.out.println("Welcome to EasyKhanBan");
                    
                    System.out.println("How many tasks do you want to enter: ");
                    
                    int taskNumber = input.nextInt();
                    
                    for (int k = 0; k < taskNumber; k++) {
                        System.out.println("Choose one of the following task:\n 1: Add Task\n 2: Show Report\n 3: Quit ");
                        int task = input.nextInt();
                        input.nextLine();
                        if (task == 1) {
                            System.out.println("Please give the task name: ");
                            String taskName = input.nextLine();

                            System.out.println("Task number " + k);

                            System.out.println("Please give the task Description");
                            String taskDescription = input.nextLine();

                            while (taskClass.taskDescription(taskDescription) == false) {
                                System.out.println("Task descriptions have to be less than 50 characters,\n"
                                        + "Please give the task Description again: ");
                                taskDescription = input.nextLine();
                            }
                            System.out.println("Please provide first and last name of the developer: ");
                            String nameSurnameDetails = input.nextLine();

                            System.out.println("Please give the task duration: ");

                            int taskDuration = input.nextInt();
                            taskClass.totalHours(taskDuration);
                            System.out.println("Task ID: " + taskClass.taskID(taskName, k, nameSurnameDetails));
                            
                            System.out.println("Choose the number to give status to developer:\n 1: ToDo \n 2: Done \n 3: Doing ");
                            int status = input.nextInt();
                            
                            if (status == 1) {
                                JOptionPane.showMessageDialog(null, taskClass.allTaskDetails("ToDo", nameSurnameDetails, k, taskName, taskDescription, taskClass.taskID(taskName, k, nameSurnameDetails), taskDuration));
                                if (k == taskNumber - 1) {

                                    JOptionPane.showMessageDialog(null, "Total duration: " + taskClass.totalHours(0) + "hours");
                                }

                            } else if (status == 2) {
                                JOptionPane.showMessageDialog(null, taskClass.allTaskDetails("Done", nameSurnameDetails, k, taskName, taskDescription, taskClass.taskID(taskName, k, nameSurnameDetails), taskDuration));
                                if (k == taskNumber - 1) {

                                    JOptionPane.showMessageDialog(null, "Total duration: " + taskClass.totalHours(0) + "hours");
                                }
                            } else if (status == 3) {
                                JOptionPane.showMessageDialog(null, taskClass.allTaskDetails("Doing", nameSurnameDetails, k, taskName, taskDescription, taskClass.taskID(taskName, k, nameSurnameDetails), taskDuration));
                                if (k == taskNumber - 1) {

                                    JOptionPane.showMessageDialog(null, "Total duration: " + taskClass.totalHours(0) + "hours");
                                }
                            } else {
                                System.out.println("Wrong Number");
                            }
                        } else if (task == 2) {

                            System.out.println("Coming Soon");
                            k--;
                            continue;
                        } else if (task == 3) {
                            System.out.println("Program has ended");
                            break;
                        } else {
                            System.out.println("Incorrect number has been choosen");
                            k--;
                            continue;
                        }
                    }
                } else {
                    // the below statement outputs the response when the username and password are incorrectly entered.

                    System.out.println(loginMethod.returnLoginStatus(""));
                }

            } else {
                // the below statement outputs two response depending if the username is incorrect or password is incorrecet.

                System.out.println(loginMethod.registerUser(username, password));
            }
        } else {
            // the below statement outputs a response when the username is entered  incorrectly. 

            String password = "";

            System.out.println(loginMethod.registerUser(username, password));
        }
    }

}
